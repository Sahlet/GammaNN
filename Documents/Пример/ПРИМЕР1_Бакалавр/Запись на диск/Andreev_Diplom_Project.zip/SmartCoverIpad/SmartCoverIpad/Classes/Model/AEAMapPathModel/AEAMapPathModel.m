//
//  AEAMapPathModel.m
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 4/19/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import "AEAMapPathModel.h"
#import "AEAOverlay.h"
#import "AEARoute.h"
#import "AEAPath.h"
#import "NSSet+Combinatorics.h"

@implementation AEAMapPathModel

- (instancetype)init {
    self = [super init];
    if (self) {
        self.overlays = [NSMutableArray new];
        NSString *path = [[NSBundle mainBundle] pathForResource:@"ATMLocations" ofType:@"plist"];
        NSArray *locations = [NSArray arrayWithContentsOfFile:path];
        for (int i=0;i<5;i++) {
            NSDictionary *row = locations[i];
            [self.overlays addObject:[AEAOverlay overlayFromDictionary:row]];
        }
    }
    return self;
}

- (void)calculateDistanceToUser {
    self.distances = [NSMutableArray new];
    for (AEAOverlay *overlay in self.overlays) {
        MKDirectionsRequest *directionsRequest = [[MKDirectionsRequest alloc] init];
        MKPlacemark *placemark = [[MKPlacemark alloc] initWithCoordinate:overlay.coordinate
                                                       addressDictionary:nil];
        [directionsRequest setSource:[MKMapItem mapItemForCurrentLocation]];
        [directionsRequest setDestination:[[MKMapItem alloc] initWithPlacemark:placemark]];
        
        directionsRequest.transportType = MKDirectionsTransportTypeWalking;
        MKDirections *directions = [[MKDirections alloc] initWithRequest:directionsRequest];
        __weak typeof(self) weakSelf = self;
        [directions calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
            if (error) {
                NSLog(@"Error %@", error.description);
            } else {
                AEARoute *overlayDistance = [AEARoute new];
                overlayDistance.routeDetails = response.routes.lastObject;
                overlayDistance.overlay = overlay;
                MKRoute *routeDetails = response.routes.lastObject;
                overlayDistance.distance = routeDetails.distance;
                overlayDistance.travelTime = routeDetails.expectedTravelTime;
                overlayDistance.polyline = routeDetails.polyline;
                [weakSelf.userOverlay.distances addObject:overlayDistance];
            }
        }];
    }
}

- (void)calculateDistancesBetweenOverlaysWithCompletion:(void (^)(void))completionBlock {
    dispatch_group_t overlayGroup = dispatch_group_create();
    for (AEAOverlay *overlay in self.overlays) {
        [self.overlays enumerateObjectsUsingBlock:^(AEAOverlay *obj, NSUInteger idx, BOOL *stop) {
            if (![obj isEqual:overlay]) {
                MKDirectionsRequest *directionsRequest = [[MKDirectionsRequest alloc] init];
                MKPlacemark *sourcePlacemark = [[MKPlacemark alloc] initWithCoordinate:overlay.coordinate
                                                                     addressDictionary:nil];
                MKPlacemark *destinationPlacemark = [[MKPlacemark alloc] initWithCoordinate:obj.coordinate
                                                                          addressDictionary:nil];
                [directionsRequest setSource:[[MKMapItem alloc] initWithPlacemark:sourcePlacemark]];
                [directionsRequest setDestination:[[MKMapItem alloc] initWithPlacemark:destinationPlacemark]];
                directionsRequest.transportType = MKDirectionsTransportTypeWalking;
                MKDirections *directions = [[MKDirections alloc] initWithRequest:directionsRequest];
                dispatch_group_enter(overlayGroup);
                [directions calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
                    if (error) {
                        NSLog(@"Error %@", error.description);
                    } else {
                        AEARoute *overlayDistance = [AEARoute new];
                        overlayDistance.routeDetails = response.routes.lastObject;
                        overlayDistance.overlay = obj;
                        MKRoute *routeDetails = response.routes.lastObject;
                        overlayDistance.distance = routeDetails.distance;
                        overlayDistance.polyline = routeDetails.polyline;
                        overlayDistance.travelTime = routeDetails.expectedTravelTime;
                        [overlay.distances addObject:overlayDistance];
                    }
                    dispatch_group_leave(overlayGroup);
                }];
            }
        }];
        
    }
    dispatch_group_notify(overlayGroup,dispatch_get_main_queue(), ^{
        if (completionBlock) {
            completionBlock();
        }
    });
}

- (AEAPath *)findMinimumDistancePathWithCount:(NSInteger)count {
    __block NSArray *variations = [[[NSSet setWithArray:self.overlays] variationsOfSize:count] allObjects];
    __block NSMutableArray *pathes = [NSMutableArray new];
    AEAPath *minimumPath = nil;
    for (NSMutableArray *variation in variations) {
        AEAPath *path = [AEAPath pathWithStartOverlay:self.userOverlay andArray:variation];
        if (!minimumPath) {
            minimumPath = path;
        } else {
            if (path.distance < minimumPath.distance) {
                minimumPath = path;
            }
        }
        [pathes addObject:path];
    }
    return minimumPath;
}

- (AEAPath *)findMinimumPathWithDistance:(double)distance {
    NSMutableArray *variations = [NSMutableArray new];
    NSSet *overlaysSet = [NSSet setWithArray:self.overlays];
    for (int i=1; i<=5; i++) {
        [variations addObjectsFromArray:[[overlaysSet variationsOfSize:i] allObjects]];
    }
    AEAPath *minimumPath = nil;
    for (NSMutableArray *variation in variations) {
        AEAPath *path = [AEAPath pathWithStartOverlay:self.userOverlay andArray:variation];
        if (!minimumPath && path.distance < distance) {
            minimumPath = path;
        } else {
            if ([path.routes count] > [minimumPath.routes count] && path.distance < distance) {
                minimumPath = path;
            }
        }
    }
    return minimumPath;
}

- (AEAPath *)findMinimumPathWithTime:(NSTimeInterval)time {
    NSMutableArray *variations = [NSMutableArray new];
    NSSet *overlaysSet = [NSSet setWithArray:self.overlays];
    for (int i=1; i<=5; i++) {
        [variations addObjectsFromArray:[[overlaysSet variationsOfSize:i] allObjects]];
    }
    AEAPath *minimumPath = nil;
    for (NSMutableArray *variation in variations) {
        AEAPath *path = [AEAPath pathWithStartOverlay:self.userOverlay andArray:variation];
        if (!minimumPath && path.travelTime < time) {
            minimumPath = path;
        } else {
            if ([path.routes count] > [minimumPath.routes count] && path.travelTime < time) {
                minimumPath = path;
            }
        }
    }
    return minimumPath;
}

@end
