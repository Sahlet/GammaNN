//
//  AEAOverlay.h
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 4/11/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import <Foundation/Foundation.h>
@import MapKit;

@interface AEAOverlay : NSObject 


@property (nonatomic, strong) NSNumber *latitude;
@property (nonatomic, strong) NSNumber *longitude;
@property (nonatomic, assign) CLLocationCoordinate2D coordinate;
@property (nonatomic, strong) NSString *overlayTitle;
@property (nonatomic, strong) NSMutableArray *distances;

+ (AEAOverlay *)overlayFromDictionary:(NSDictionary *)dictionary;

@end
