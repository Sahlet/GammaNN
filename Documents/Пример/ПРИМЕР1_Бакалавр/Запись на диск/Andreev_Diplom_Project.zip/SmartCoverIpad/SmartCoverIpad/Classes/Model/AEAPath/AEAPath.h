//
//  AEAPath.h
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 4/12/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AEAOverlay.h"
#import "AEARoute.h"

@interface AEAPath : NSObject

@property (nonatomic, strong) AEAOverlay *startOverlay;
@property (nonatomic, strong) NSMutableArray *routes;
@property (nonatomic, readonly) double distance;
@property (nonatomic, readonly) NSTimeInterval travelTime;

+ (AEAPath*)pathWithStartOverlay:(AEAOverlay *)startOverlay andArray:(NSMutableArray *)overlays;

@end
