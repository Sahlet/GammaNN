//
//  AEAOverlay.m
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 4/11/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import "AEAOverlay.h"

@implementation AEAOverlay

- (NSMutableArray *)distances {
    if (!_distances) {
        _distances = [NSMutableArray array];
    }
    return _distances;
}

+ (AEAOverlay *)overlayFromDictionary:(NSDictionary *)dictionary {
    AEAOverlay *overlay = [AEAOverlay new];
    overlay.latitude = [dictionary objectForKey:@"latitude"];
    overlay.longitude = [dictionary objectForKey:@"longitude"];
    overlay.coordinate = CLLocationCoordinate2DMake(overlay.latitude.doubleValue, overlay.longitude.doubleValue);
    overlay.overlayTitle = [dictionary objectForKey:@"title"];
    return overlay;
}

@end
