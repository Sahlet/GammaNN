//
//  AEADistance.m
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 4/11/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import "AEARoute.h"

@implementation AEARoute
@synthesize coordinate;
@synthesize boundingMapRect;

@end
