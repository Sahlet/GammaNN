//
//  AEAMenuViewController.h
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 6/13/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AEAMenuViewController : UIViewController

@end
