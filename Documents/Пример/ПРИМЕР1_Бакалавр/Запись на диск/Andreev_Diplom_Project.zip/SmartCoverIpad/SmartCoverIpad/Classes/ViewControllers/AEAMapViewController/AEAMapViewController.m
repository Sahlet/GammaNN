//
//  AEAMapViewController.m
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 4/1/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import "AEAMapViewController.h"
#import "NSSet+Combinatorics.h"
#import "AEAOverlay.h"
#import "AEARoute.h"
#import "AEAPath.h"

#import "AEAMapPathModel.h"
#import <FlatUIKit.h>

@import MapKit;

@interface AEAMapViewController () <MKMapViewDelegate, CLLocationManagerDelegate>

@property (nonatomic, weak) IBOutlet MKMapView *mapView;
@property (nonatomic, weak) IBOutlet FUIButton *calculateButton;
@property (nonatomic, weak) IBOutlet FUISegmentedControl *filterSegmentControl;
@property (nonatomic, weak) IBOutlet UILabel *filterLabel;
@property (nonatomic, weak) IBOutlet FUITextField *timeAndDistanceTextField;
@property (nonatomic, weak) IBOutlet UIStepper *searchCountStepper;
@property (weak, nonatomic) IBOutlet UILabel *distanceAndTimeLabel;

@property (nonatomic, strong) CLLocationManager *locationManager;
@property (nonatomic, strong) MKRoute *route;
@property (nonatomic, strong) NSMutableArray *annotations;
@property (nonatomic, strong) NSMutableArray *overlays;
@property (nonatomic, strong) NSMutableArray *distances;
@property (nonatomic, strong) AEAOverlay *userOverlay;
@property (nonatomic, strong) AEAPath *minimumPath;

@property (nonatomic, strong) AEAMapPathModel *model;

@end

@implementation AEAMapViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor midnightBlueColor];
    self.model = [[AEAMapPathModel alloc] init];
//    self.mapView.delegate = self;
    self.locationManager = [[CLLocationManager alloc] init];
    [self.locationManager requestAlwaysAuthorization];
    [self.locationManager requestWhenInUseAuthorization];
    
    float spanX = 0.50725;
    float spanY = 0.50725;
    MKCoordinateRegion region;
    region.center.latitude = 48.454786;
    region.center.longitude = 35.022574;
    region.span = MKCoordinateSpanMake(spanX, spanY);
    [self.mapView setRegion:region animated:YES];
    NSString *path = [[NSBundle mainBundle] pathForResource:@"ATMLocations" ofType:@"plist"];
    NSArray *locations = [NSArray arrayWithContentsOfFile:path];
    self.annotations = [NSMutableArray new];
    self.overlays = [NSMutableArray new];
    for (int i=0;i<5;i++) {
        NSDictionary *row = locations[i];
        NSNumber *latitude = [row objectForKey:@"latitude"];
        NSNumber *longitude = [row objectForKey:@"longitude"];
        NSString *title = [row objectForKey:@"title"];
        MKPointAnnotation *newPoint = [[MKPointAnnotation alloc] init];
        newPoint.coordinate = CLLocationCoordinate2DMake(latitude.doubleValue, longitude.doubleValue);
        newPoint.title = title;
        [self.annotations addObject:newPoint];
        [self.mapView addAnnotation:newPoint];
        
        [self.overlays addObject:[AEAOverlay overlayFromDictionary:row]];
    }
    [self configureUI];
}

- (void)configureUI {
    self.calculateButton.buttonColor = [UIColor turquoiseColor];
    self.calculateButton.shadowColor = [UIColor greenSeaColor];
    self.calculateButton.shadowHeight = 5.f;
    self.calculateButton.cornerRadius = 15.f;
    self.calculateButton.titleLabel.font = [UIFont boldFlatFontOfSize:26.f];
    [self.calculateButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateNormal];
    [self.calculateButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateHighlighted];
    
    self.filterSegmentControl.selectedFont = [UIFont boldFlatFontOfSize:20];
    self.filterSegmentControl.selectedFontColor = [UIColor cloudsColor];
    self.filterSegmentControl.deselectedFont = [UIFont flatFontOfSize:20];
    self.filterSegmentControl.deselectedFontColor = [UIColor cloudsColor];
    self.filterSegmentControl.selectedColor = [UIColor peterRiverColor];
    self.filterSegmentControl.deselectedColor = [UIColor concreteColor];
    self.filterSegmentControl.cornerRadius = 6.f;
    self.filterSegmentControl.dividerColor = [UIColor belizeHoleColor];
    
    self.filterLabel.font = [UIFont boldFlatFontOfSize:20.f];
    self.filterLabel.textColor = [UIColor cloudsColor];
    self.distanceAndTimeLabel.font = [UIFont boldFlatFontOfSize:20.f];
    self.distanceAndTimeLabel.textColor = [UIColor cloudsColor];
    
    [self.searchCountStepper configureFlatStepperWithColor:[UIColor nephritisColor]
                                          highlightedColor:[UIColor emerlandColor]
                                             disabledColor:[UIColor nephritisColor]
                                                 iconColor:[UIColor cloudsColor]];
    
    self.timeAndDistanceTextField.font = [UIFont flatFontOfSize:18];
    self.timeAndDistanceTextField.backgroundColor = [UIColor whiteColor];
    self.timeAndDistanceTextField.textFieldColor = [UIColor turquoiseColor];
    self.timeAndDistanceTextField.borderColor = [UIColor turquoiseColor];
    self.timeAndDistanceTextField.borderWidth = 4.f;
    self.timeAndDistanceTextField.cornerRadius = 3.f;
    self.timeAndDistanceTextField.edgeInsets = UIEdgeInsetsMake(4.0f, 15.0f, 4.0f, 15.0f);
    
    self.timeAndDistanceTextField.hidden = YES;
    self.distanceAndTimeLabel.text = @"ATM count:0";
    self.searchCountStepper.value = 0;
    self.searchCountStepper.hidden = NO;
}

- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation {
    AEAOverlay *userOverlay = [AEAOverlay new];
    userOverlay.coordinate = userLocation.coordinate;
    userOverlay.overlayTitle = @"User location";
    self.userOverlay = userOverlay;
    self.model.userOverlay = userOverlay;
    [self.model calculateDistanceToUser];
}

- (void)mapView:(MKMapView *)mapView didFailToLocateUserWithError:(NSError *)error  {
#warning Vivesti oshibku
}

- (IBAction)calculateDistances:(id)sender {
    __weak typeof(self) weakSelf = self;
    [self.model calculateDistancesBetweenOverlaysWithCompletion:^{
        AEAPath *minimumPath = nil;
        switch (weakSelf.filterSegmentControl.selectedSegmentIndex) {
            case 0:{
                minimumPath = [weakSelf.model findMinimumDistancePathWithCount:self.searchCountStepper.value];
                break;
            }
            case 1: {
                minimumPath = [weakSelf.model findMinimumPathWithTime:self.timeAndDistanceTextField.text.doubleValue];
                break;
            }
            case 2: {
                minimumPath = [weakSelf.model findMinimumPathWithDistance:self.timeAndDistanceTextField.text.doubleValue];
                break;
            }
            default:
            break;
        }
        [self.mapView addOverlays:[minimumPath.routes valueForKey:@"polyline"]];
    }];
}


-(MKOverlayRenderer *)mapView:(MKMapView *)mapView rendererForOverlay:(id<MKOverlay>)overlay {
    if ([overlay isKindOfClass:[MKPolyline class]]) {
        MKPolylineRenderer  * routeLineRenderer = [[MKPolylineRenderer alloc] initWithPolyline:overlay];
        routeLineRenderer.strokeColor = [UIColor redColor];
        routeLineRenderer.lineWidth = 5;
        return routeLineRenderer;
    }
    return nil;
}
- (IBAction)filterValueChanged:(FUISegmentedControl*)sender {
    switch (sender.selectedSegmentIndex) {
        case 0:{
            [UIView animateWithDuration:0.5 animations:^{
                self.timeAndDistanceTextField.hidden = YES;
                self.distanceAndTimeLabel.text = @"Places count:0";
                self.searchCountStepper.value = 0;
                self.searchCountStepper.hidden = NO;
                self.searchCountStepper.maximumValue = [self.model.overlays count];
            }];
            break;
        }
        case 1: {
            [UIView animateWithDuration:0.5 animations:^{
                self.timeAndDistanceTextField.hidden = NO;
                self.distanceAndTimeLabel.text = @"Enter max time";
                self.searchCountStepper.hidden = YES;
            }];
            break;
        }
        case 2: {
            [UIView animateWithDuration:0.5 animations:^{
                self.timeAndDistanceTextField.hidden = NO;
                self.distanceAndTimeLabel.text = @"Enter max distance";
                self.searchCountStepper.hidden = YES;
            }];
            break;
        }
        default:
            break;
    }
}

- (IBAction)valueChanged:(UIStepper *)sender {
    double value = [sender value];
    
    [self.distanceAndTimeLabel setText:[NSString stringWithFormat:@"Places count:%d", (int)value]];
}

@end
