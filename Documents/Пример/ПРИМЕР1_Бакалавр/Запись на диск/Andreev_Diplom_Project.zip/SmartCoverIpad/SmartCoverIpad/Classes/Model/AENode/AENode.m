//
//  AENode.m
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 2/1/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import "AENode.h"

@implementation AENode

- (instancetype)init {
    self = [super init];
    if (self) {
        _distancesToCenters = [NSMutableArray new];
    }
    return self;
}

- (instancetype)initWithLocation:(CGPoint)location {
    
    self = [self init];
    if (self) {
        location.x = location.x > 1 ? 1 : location.x;
        location.y = location.y > 1 ? 1 : location.y;
        _location = location;
    }
    return self;
}

@end
