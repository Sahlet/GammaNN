//
//  AEAMenuViewController.m
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 6/13/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import "AEAMenuViewController.h"
#import <FlatUIKit.h>

@interface AEAMenuViewController ()

@property (nonatomic, weak) IBOutlet FUIButton *pathButton;
@property (nonatomic, weak) IBOutlet FUIButton *coverButton;

@end

@implementation AEAMenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor belizeHoleColor];
    
    self.pathButton.buttonColor = [UIColor turquoiseColor];
    self.pathButton.shadowColor = [UIColor greenSeaColor];
    self.pathButton.shadowHeight = 5.f;
    self.pathButton.cornerRadius = 15.f;
    self.pathButton.titleLabel.font = [UIFont boldFlatFontOfSize:60.f];
    [self.pathButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateNormal];
    [self.pathButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateHighlighted];
    
    self.coverButton.buttonColor = [UIColor nephritisColor];
    self.coverButton.shadowColor = [UIColor greenSeaColor];
    self.coverButton.shadowHeight = 5.f;
    self.coverButton.cornerRadius = 15.f;
    self.coverButton.titleLabel.font = [UIFont boldFlatFontOfSize:60.f];
    [self.coverButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateNormal];
    [self.coverButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateHighlighted];
}


@end
