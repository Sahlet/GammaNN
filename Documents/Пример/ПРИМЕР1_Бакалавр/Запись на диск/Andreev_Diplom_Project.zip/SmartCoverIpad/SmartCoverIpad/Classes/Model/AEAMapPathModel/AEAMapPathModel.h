//
//  AEAMapPathModel.h
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 4/19/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import <Foundation/Foundation.h>
@import UIKit;
@import MapKit;

@class AEAOverlay;
@class AEAPath;

@interface AEAMapPathModel : NSObject

@property (nonatomic, strong) NSMutableArray *annotations;
@property (nonatomic, strong) NSMutableArray *overlays;
@property (nonatomic, strong) NSMutableArray *distances;
@property (nonatomic, strong) AEAOverlay *userOverlay;


- (void)calculateDistanceToUser;
- (void)calculateDistancesBetweenOverlaysWithCompletion:(void (^)(void))completionBlock;
- (AEAPath *)findMinimumDistancePathWithCount:(NSInteger)count;
- (AEAPath *)findMinimumPathWithDistance:(double)distance;
- (AEAPath *)findMinimumPathWithTime:(NSTimeInterval)time;

@end
