//
//  AETouchableView.h
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 2/4/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AETouchableView;

@protocol AETouchableViewDelegate <NSObject>

- (void)touchableView:(AETouchableView *)view didAddedCenter:(CGPoint)center;

@end

@interface AETouchableView : UIView

- (void)removeCenters;

@property (nonatomic, weak) id<AETouchableViewDelegate> delegate;

@property (nonatomic) CGFloat coverZoneRadius;

- (void)addCenter:(CGPoint)center;

@end
