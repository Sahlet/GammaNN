//
//  AEAPath.m
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 4/12/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import "AEAPath.h"

@implementation AEAPath

- (NSMutableArray *)routes {
    if (!_routes) {
        _routes = [NSMutableArray array];
    }
    return _routes;
}

- (double)distance {
    double result = 0;
    for (AEARoute *route in self.routes) {
        result += route.distance;
    }
    return result;
}

- (NSTimeInterval)travelTime {
    double travelTime = 0;
    for (AEARoute *route in self.routes) {
        travelTime += route.travelTime;
    }
    return travelTime;
}

+ (AEAPath *)pathWithStartOverlay:(AEAOverlay *)startOverlay andArray:(NSMutableArray *)overlays {
    AEAPath *path = [AEAPath new];
    AEAOverlay *firstOverlay = [overlays firstObject];
    NSArray *filteredArray = [startOverlay.distances filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"overlay == %@",firstOverlay]];
    AEARoute *routeFromUser = [filteredArray firstObject];
    [path.routes addObject:routeFromUser];
    
    for (int i = 0; i < [overlays count] - 1; i++) {
        AEAOverlay *currentOverlay = overlays[i];
        AEAOverlay *nextOverlay = overlays[i + 1];
        NSArray *nextDistances = [currentOverlay.distances filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"overlay == %@",nextOverlay]];
        AEARoute *currentRoute = [nextDistances firstObject];
        [path.routes addObject:currentRoute];
    }
    AEAOverlay *lastOverlay = [overlays lastObject];
    filteredArray = [startOverlay.distances filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"overlay == %@",lastOverlay]];
    AEARoute *routeToUser = [filteredArray firstObject];
    [path.routes addObject:routeToUser];
    NSLog(@"%f",path.distance);
    path.startOverlay = startOverlay;
    return path;
}

@end
