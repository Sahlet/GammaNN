//
//  AEAAddCenterViewController.m
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 6/14/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import "AEAAddCenterViewController.h"
#import <FlatUIKit.h>

@interface AEAAddCenterViewController ()

@property (nonatomic, weak) IBOutlet FUIButton *addButton;
@property (nonatomic, weak) IBOutlet FUITextField *xTextfield;
@property (nonatomic, weak) IBOutlet FUITextField *yTextfield;

@end

@implementation AEAAddCenterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor turquoiseColor];
    
    self.xTextfield.font = [UIFont flatFontOfSize:26];
    self.xTextfield.backgroundColor = [UIColor whiteColor];
    self.xTextfield.textFieldColor = [UIColor turquoiseColor];
    self.xTextfield.borderColor = [UIColor turquoiseColor];
    self.xTextfield.borderWidth = 4.f;
    self.xTextfield.cornerRadius = 3.f;
    self.xTextfield.edgeInsets = UIEdgeInsetsMake(4.0f, 15.0f, 4.0f, 15.0f);
    
    self.yTextfield.font = [UIFont flatFontOfSize:26];
    self.yTextfield.backgroundColor = [UIColor whiteColor];
    self.yTextfield.textFieldColor = [UIColor turquoiseColor];
    self.yTextfield.borderColor = [UIColor turquoiseColor];
    self.yTextfield.borderWidth = 4.f;
    self.yTextfield.cornerRadius = 3.f;
    self.yTextfield.edgeInsets = UIEdgeInsetsMake(4.0f, 15.0f, 4.0f, 15.0f);
    
    self.addButton.buttonColor = [UIColor nephritisColor];
    self.addButton.shadowColor = [UIColor greenSeaColor];
    self.addButton.shadowHeight = 5.f;
    self.addButton.cornerRadius = 15.f;
    self.addButton.titleLabel.font = [UIFont boldFlatFontOfSize:40.f];
    [self.addButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateNormal];
    [self.addButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateHighlighted];
}


- (IBAction)addTouched:(id)sender {
    [self.delegate centerWasAdded:CGPointMake(self.xTextfield.text.doubleValue, self.yTextfield.text.doubleValue)];
}



@end
