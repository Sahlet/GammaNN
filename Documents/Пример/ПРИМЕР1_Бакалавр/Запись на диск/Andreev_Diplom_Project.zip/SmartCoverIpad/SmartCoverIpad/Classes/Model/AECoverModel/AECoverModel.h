//
//  AECoverModel.h
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 2/1/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import <Foundation/Foundation.h>
@import UIKit;

@interface AECoverModel : NSObject

@property (nonatomic) NSUInteger numberOfNetPoints;

@property (nonatomic) NSUInteger coverNumber;
@property (nonatomic) CGFloat maxRadius;
@property (nonatomic, readonly) NSUInteger numberOfCenters;

- (instancetype)initWithCenters:(NSMutableArray *)centers;

- (void)addCenter:(CGPoint)center;

- (void)findMaxRadius;

- (void)clear;

@end
