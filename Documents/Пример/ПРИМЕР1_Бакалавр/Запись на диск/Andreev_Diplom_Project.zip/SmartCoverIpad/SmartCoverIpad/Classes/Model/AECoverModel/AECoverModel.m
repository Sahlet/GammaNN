//
//  AECoverModel.m
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 2/1/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import "AECoverModel.h"
#import "AENode.h"

@interface AECoverModel()

@property (nonatomic, strong) NSMutableArray *centers;
@property (nonatomic, strong) NSMutableArray *distancesBetweenCenters;
@property (nonatomic, strong) NSMutableArray *nodeArray;

@end

@implementation AECoverModel

#pragma mark - Lifecycle

- (instancetype)init {
    self = [super init];
    if (self) {
        _distancesBetweenCenters = [NSMutableArray new];
        _centers = [NSMutableArray new];
        _nodeArray = [NSMutableArray new];
        self.numberOfNetPoints = 10;
        _coverNumber = 1;
    }
    return self;
}

- (instancetype)initWithCenters:(NSMutableArray *)centers {
    self = [self init];
    if (self) {
        _centers = centers;
    }
    return self;
}

- (void)addCenter:(CGPoint)center {
    [self.centers addObject:[NSValue valueWithCGPoint:center]];
}

- (void)setNumberOfNetPoints:(NSUInteger)numberOfNetPoints {
    _numberOfNetPoints = numberOfNetPoints;
    [self resetNodes];
}

#pragma mark - Private

- (void)resetNodes {
    CGFloat step = 1.f/self.numberOfNetPoints;
    [self.nodeArray removeAllObjects];
    for (int i = 0; i <= self.numberOfNetPoints; i ++) {
        for (int j = 0; j <= self.numberOfNetPoints; j ++) {
            [self.nodeArray addObject:[[AENode alloc] initWithLocation:CGPointMake(i*step,j*step)]];
        }
    }
}

- (void)calculateDistances {
    __weak typeof(self) weakSelf = self;
    [self.nodeArray enumerateObjectsUsingBlock:^(AENode *node, NSUInteger idx, BOOL *stop) {
        [node.distancesToCenters removeAllObjects];
        [weakSelf.centers enumerateObjectsUsingBlock:^(NSValue *center, NSUInteger idx, BOOL *stop) {
            CGPoint centerPoint = center.CGPointValue;
            double distance = [self distanceBetweenA:node.location B:centerPoint];
            [node.distancesToCenters addObject:[NSNumber numberWithDouble:distance]];
        }];
    }];
}

- (void)sortNodesDistances {
    [self.nodeArray enumerateObjectsUsingBlock:^(AENode *node, NSUInteger idx, BOOL *stop) {
        node.distancesToCenters = [[node.distancesToCenters sortedArrayUsingSelector:@selector(compare:)] mutableCopy];
    }];
}

- (double)distanceBetweenA:(CGPoint)firstPoint B:(CGPoint)secondPoint {
    return MAX(fabs(firstPoint.x-secondPoint.x), fabs(firstPoint.y-secondPoint.y));
}

- (double)calculateMaxRadius {
    __block double maxRadius = 0;
    __weak typeof(self) weakSelf = self;
    [self.nodeArray enumerateObjectsUsingBlock:^(AENode *obj, NSUInteger idx, BOOL *stop) {
        NSNumber *distance = obj.distancesToCenters[weakSelf.coverNumber-1];
        maxRadius = MAX(distance.doubleValue, maxRadius);
    }];
    return maxRadius;
}

#pragma mark - Public

- (void)findMaxRadius {
    [self calculateDistances];
    [self sortNodesDistances];
    self.maxRadius = [self calculateMaxRadius];
}

- (NSUInteger)numberOfCenters {
    return [self.centers count];
}

- (void)clear {
    [self.centers removeAllObjects];
    [self resetNodes];
    self.coverNumber = 1;
}

@end
