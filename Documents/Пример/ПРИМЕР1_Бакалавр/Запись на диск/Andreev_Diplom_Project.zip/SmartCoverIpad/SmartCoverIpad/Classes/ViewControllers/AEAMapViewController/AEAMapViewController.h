//
//  AEAMapViewController.h
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 4/1/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AEAMapViewController : UIViewController

@end
