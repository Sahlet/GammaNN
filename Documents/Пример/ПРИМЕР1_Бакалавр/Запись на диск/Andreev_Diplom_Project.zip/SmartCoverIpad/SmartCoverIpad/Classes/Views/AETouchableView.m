//
//  AETouchableView.m
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 2/4/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import "AETouchableView.h"
#import <QuartzCore/QuartzCore.h>

@interface AETouchableView()

@property (nonatomic, strong) NSMutableArray *centersPathes;
@property (nonatomic, strong) NSMutableArray *nodeLinesPathes;
@property (nonatomic) NSInteger netLinesNumber;
@property (nonatomic, strong) NSMutableArray *centers;

@end

@implementation AETouchableView

- (NSMutableArray *)centersPathes {
    if (!_centersPathes) {
        _centersPathes = [NSMutableArray new];
    }
    return _centersPathes;
}

- (NSMutableArray *)centers {
    if (!_centers) {
        _centers = [NSMutableArray new];
    }
    return _centers;
}

- (void)setCoverZoneRadius:(CGFloat)coverZoneRadius {
    _coverZoneRadius = coverZoneRadius;
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    [self drawNet];
    [self drawCenters];
    if (self.coverZoneRadius > 0.f) {
        [self drawCoverZone];
    }
}

- (void)drawCenters {
    [[UIColor redColor] setFill];
    [self.centersPathes enumerateObjectsUsingBlock:^(UIBezierPath *path, NSUInteger idx, BOOL *stop) {
        [path fill];
        [path stroke];
    }];
}

- (void)drawNet {
    [[UIColor lightGrayColor] setFill];
    [[UIColor lightGrayColor] setStroke];
    CGFloat step = self.frame.size.width / 10;
    CGFloat dash[] = {2.0, 2.0};
    for (int i=step; i< self.frame.size.width; i=i+step) {
        UIBezierPath *netHorizontalLine = [UIBezierPath bezierPath];
        [netHorizontalLine setLineDash:dash count:2 phase:0.0];
        [netHorizontalLine moveToPoint:CGPointMake(i, 0)];
        [netHorizontalLine addLineToPoint:CGPointMake(i, self.frame.size.width)];
        UIBezierPath *netVerticalLine = [UIBezierPath bezierPath];
        [netVerticalLine setLineDash:dash count:2 phase:0.0];
        [netVerticalLine moveToPoint:CGPointMake(0, i)];
        [netVerticalLine addLineToPoint:CGPointMake(self.frame.size.width, i)];
        [netHorizontalLine stroke];
        [netVerticalLine stroke];
    }
}

- (void)drawCoverZone {
    [self.centers enumerateObjectsUsingBlock:^(NSValue *obj, NSUInteger idx, BOOL *stop) {
        CGPoint center = obj.CGPointValue;
        [[UIColor blueColor] setStroke];
        UIBezierPath *centerBezierPath = [UIBezierPath bezierPathWithRect:CGRectMake(center.x-self.coverZoneRadius, center.y - self.coverZoneRadius, self.coverZoneRadius*2, self.coverZoneRadius*2)];
        [centerBezierPath stroke];
    }];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    self.coverZoneRadius = 0.f;
    CGPoint touch = [[touches anyObject] locationInView:self];
    UIBezierPath *centerBezierPath = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(touch.x-5.f, touch.y-5.f, 10.f, 10.f)];
    [self.centersPathes addObject:centerBezierPath];
    [self.delegate touchableView:self didAddedCenter:touch];
    [self.centers addObject:[NSValue valueWithCGPoint:touch]];
    [self setNeedsDisplay];
}


- (void)removeCenters {
    self.coverZoneRadius = 0.f;
    [self.centersPathes removeAllObjects];
    [self setNeedsDisplay];
}

- (void)addCenter:(CGPoint)center {
    self.coverZoneRadius = 0.f;
    CGPoint touch = CGPointMake(center.x*self.frame.size.width, center.y*self.frame.size.height);
    UIBezierPath *centerBezierPath = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(touch.x-5.f, touch.y-5.f, 10.f, 10.f)];
    [self.centersPathes addObject:centerBezierPath];
    [self.delegate touchableView:self didAddedCenter:touch];
    [self.centers addObject:[NSValue valueWithCGPoint:touch]];
    [self setNeedsDisplay];
}

@end
