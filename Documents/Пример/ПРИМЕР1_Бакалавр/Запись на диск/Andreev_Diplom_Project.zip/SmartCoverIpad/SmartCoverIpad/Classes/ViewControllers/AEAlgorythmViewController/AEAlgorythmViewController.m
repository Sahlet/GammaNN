//
//  AEAlgorythmViewController.m
//  SmartCoverIpad
//
//  Created by Eugene Andreyev on 2/4/15.
//  Copyright (c) 2015 Eugene Andreyev. All rights reserved.
//

#import "AEAlgorythmViewController.h"
#import "AETouchableView.h"
#import "AECoverModel.h"
#import <FlatUIKit.h>
#import "AEAAddCenterViewController.h"
#import <UIPopoverController+FlatUI.h>

@interface AEAlgorythmViewController () <AETouchableViewDelegate, UIScrollViewDelegate, UIPopoverControllerDelegate,
AEAAddCenterViewControllerDelegate>

@property (nonatomic, weak) IBOutlet AETouchableView *touchableView;
@property (nonatomic, weak) IBOutlet UILabel *radiusTextLabel;
@property (nonatomic, weak) IBOutlet UILabel *coverTextLabel;
@property (nonatomic, weak) IBOutlet UILabel *radiusLabel;
@property (nonatomic, weak) IBOutlet UILabel *coverLabel;
@property (nonatomic, weak) IBOutlet UISlider *coverSlider;
@property (nonatomic, weak) IBOutlet FUIButton *clearButton;
@property (nonatomic, weak) IBOutlet FUIButton *calcButton;
@property (nonatomic, weak) IBOutlet FUIButton *plusButton;

@property (nonatomic, strong) AECoverModel *coverModel;


@end

@implementation AEAlgorythmViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.coverModel = [[AECoverModel alloc] init];
    self.coverModel.numberOfNetPoints = 10;
    self.touchableView.delegate = self;
    [self configureUI];
}

- (void)configureUI {
    self.view.backgroundColor = [UIColor wetAsphaltColor];
    
    self.radiusLabel.font = [UIFont boldFlatFontOfSize:30.f];
    self.radiusLabel.textColor = [UIColor cloudsColor];
    self.coverLabel.font = [UIFont boldFlatFontOfSize:20.f];
    self.coverLabel.textColor = [UIColor cloudsColor];
    self.radiusTextLabel.font = [UIFont boldFlatFontOfSize:30.f];
    self.radiusTextLabel.textColor = [UIColor cloudsColor];
    self.coverTextLabel.font = [UIFont boldFlatFontOfSize:20.f];
    self.coverTextLabel.textColor = [UIColor cloudsColor];
    
    [self.coverSlider configureFlatSliderWithTrackColor:[UIColor concreteColor]
                                          progressColor:[UIColor peterRiverColor]
                                             thumbColor:[UIColor belizeHoleColor]];
    
    self.calcButton.buttonColor = [UIColor turquoiseColor];
    self.calcButton.shadowColor = [UIColor greenSeaColor];
    self.calcButton.shadowHeight = 5.f;
    self.calcButton.cornerRadius = 15.f;
    self.calcButton.titleLabel.font = [UIFont boldFlatFontOfSize:26.f];
    [self.calcButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateNormal];
    [self.calcButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateHighlighted];
    
    self.clearButton.buttonColor = [UIColor turquoiseColor];
    self.clearButton.shadowColor = [UIColor greenSeaColor];
    self.clearButton.shadowHeight = 5.f;
    self.clearButton.cornerRadius = 15.f;
    self.clearButton.titleLabel.font = [UIFont boldFlatFontOfSize:26.f];
    [self.clearButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateNormal];
    [self.clearButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateHighlighted];
}

- (void)touchableView:(AETouchableView *)view didAddedCenter:(CGPoint)center {
    [self.coverModel addCenter:CGPointMake(center.x/view.frame.size.width, center.y/view.frame.size.height)];
    self.coverSlider.maximumValue = [self.coverModel numberOfCenters];
}

- (IBAction)findRadius:(id)sender {
    self.coverModel.coverNumber =roundl(self.coverSlider.value);
    [self.coverModel findMaxRadius];
    self.touchableView.coverZoneRadius = self.coverModel.maxRadius*self.touchableView.frame.size.width;
    self.radiusLabel.text = [NSString stringWithFormat:@"%f",self.coverModel.maxRadius];
}

- (IBAction)coverSliderValueChanged:(UISlider *)sender {
    NSInteger value = roundl(sender.value);
    self.coverLabel.text = [NSString stringWithFormat:@"%li",(long)value];
    [sender setValue:(float)value];
}

- (IBAction)clearDrawingView:(id)sender {
    [self.touchableView removeCenters];
    [self.coverModel clear];
    [self.coverSlider setValue:1.f];
}

- (IBAction)plustTouched:(id)sender {
    AEAAddCenterViewController *destinationController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:NSStringFromClass([AEAAddCenterViewController class])];
    destinationController.delegate = self;
    UIPopoverController *popover = [[UIPopoverController alloc] initWithContentViewController:destinationController];
    [popover configureFlatPopoverWithBackgroundColor: [UIColor midnightBlueColor] cornerRadius:3];
    popover.delegate = self;
    [popover presentPopoverFromRect:self.plusButton.frame inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
}

- (BOOL)popoverControllerShouldDismissPopover:(UIPopoverController *)popoverController {
    return YES;
}

- (void)centerWasAdded:(CGPoint)center {
    [self.touchableView addCenter:center];
}

@end
